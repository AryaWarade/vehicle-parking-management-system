from .model import db, User, ParkingLot, ParkingSpot, Reservation
