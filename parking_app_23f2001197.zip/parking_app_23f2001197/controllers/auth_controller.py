from flask import Blueprint,render_template, request, redirect, session, url_for,flash
from flask_login import login_required,login_user,logout_user,current_user
from werkzeug.security import generate_password_hash, check_password_hash

from models import db,User

auth_bp = Blueprint('auth', __name__)

# ---------- LOGIN ROUTE ----------
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user is None:
            flash("No user found with this email.","danger")
            return redirect(url_for('auth.register')) 
        if check_password_hash(user.password, password):
            login_user(user)
            if user.is_admin:
                return redirect(url_for('admin.admin_dashboard'))
            else:
                return redirect(url_for("user.user_dashboard"))
        else:
            flash("Invalid password!", "danger")
            return render_template('login.html')
    
    return render_template('login.html')

# ---------- REGISTER ROUTE ----------
@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        full_name = request.form.get('full_name')
        address = request.form.get('address')
        pin_code = request.form.get('pin_code')
        
        user_exists=User.query.filter_by(email=email).first()

        if user_exists:
             flash('User already exists!',"warning")
             return render_template('register.html')
        hashed_password = generate_password_hash(password)

        new_user = User(email=email, password=hashed_password, full_name=full_name, address=address, pin_code=pin_code)
        db.session.add(new_user)
        db.session.commit()
        flash("Registration successful! Please login.","success")
        
        return redirect(url_for('auth.login'))
    return render_template('register.html')
                                

# ---------- LOGOUT ROUTE ----------
@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash("You have been logged out successfully.", "success")
    return redirect(url_for('auth.login')) 
