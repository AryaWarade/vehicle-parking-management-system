from flask import Blueprint,render_template, request, redirect, session, url_for,flash
from models.model import db, User, ParkingLot, ParkingSpot, Reservation
from datetime import datetime,timedelta
from flask_login import login_required,current_user
parking_bp=Blueprint('parking',__name__)

#----------BOOKING-------------------------
@parking_bp.route('/book/<int:lot_id>', methods=['GET', 'POST'])
@login_required
def book_parking(lot_id):
    if current_user.is_admin:
        flash("Admin cannot book parking spots.", "error")
        return redirect(url_for('auth.login'))

    lot = ParkingLot.query.get_or_404(lot_id)
    available_spot = ParkingSpot.query.filter_by(lot_id=lot.id, status='A').first()

    if not available_spot:
        flash("No available spots at this lot.", "warning")
        return redirect(url_for('user.user_dashboard'))
    
    active_reservation = Reservation.query.filter_by(
        user_id=current_user.id,
        leaving_timestamp=None
    ).first()

    if active_reservation:
        flash("You already have an active reservation!", "danger")
        return redirect(url_for('user.user_dashboard'))

    if request.method == 'POST':
        vehicle_number = request.form['vehicle_number']
        existing_vehicle = Reservation.query.filter_by(vehicle_number=vehicle_number)\
            .filter(Reservation.leaving_timestamp == None).first()

        if existing_vehicle:
            flash("This vehicle is already parked. Please use a different vehicle number.", "danger")
            return redirect(url_for('parking.book_parking', lot_id=lot_id))

        new_reservation = Reservation(
            user_id=current_user.id,
            spot_id=available_spot.id,
            vehicle_number=vehicle_number,
            parking_timestamp=datetime.now(),
            parking_cost=lot.price
        )

        db.session.add(new_reservation)
        available_spot.status = 'O'
        db.session.commit()

        flash("Parking spot booked successfully!", "success")
        return redirect(url_for('user.user_dashboard'))

    return render_template('book_parking.html', lot=lot, spot=available_spot)

#-----------------RELEASE----------------------------
@parking_bp.route('/release/<int:res_id>', methods=['GET', 'POST'])
@login_required
def release_parking(res_id):
    if current_user.is_admin:
        flash("Admin cannot book parking spots.", "danger")
        return redirect(url_for('auth.login'))

    reservation = Reservation.query.get_or_404(res_id)

    if reservation.user_id != current_user.id:
        flash("Unauthorized action.", "danger")
        return redirect(url_for('user.user_dashboard'))

    if request.method == 'POST':
        leaving_time = datetime.now()
        reservation.leaving_timestamp = leaving_time

        duration_minutes = (leaving_time - reservation.parking_timestamp).total_seconds() / 60
        duration_hours = duration_minutes / 60
        price_per_hour = reservation.spot.parking_lot.price
        cost = round(duration_hours * price_per_hour, 2)

        reservation.parking_cost = cost
        
        reservation.spot.status = 'A'

        db.session.commit()
        flash("Parking spot released successfully.", "success")
        return redirect(url_for('user.user_dashboard'))
    # GET
    current_time = datetime.now()
    duration_minutes = (current_time - reservation.parking_timestamp).total_seconds() / 60
    duration_hours = duration_minutes / 60
    price_per_hour = reservation.spot.parking_lot.price
    cost = round(duration_hours * price_per_hour, 2)

    return render_template('release_parking.html', reservation=reservation, cost=cost, current_time=current_time)
