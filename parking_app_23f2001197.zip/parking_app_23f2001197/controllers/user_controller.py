from flask import Blueprint,render_template, request, redirect, session, url_for,flash
from models.model import db, User, ParkingLot, ParkingSpot, Reservation
from flask_login import login_required, current_user
from werkzeug.security import generate_password_hash

user_bp=Blueprint('user',__name__)

# ---------- USER DASHBOARD ----------
@user_bp.route('/user/dashboard', methods=['GET', 'POST'])
@login_required
def user_dashboard():
    if current_user.is_admin:
        return redirect(url_for('auth.login'))
    
    search_query = request.form.get('search', '')

    if search_query:
        parking_lots = ParkingLot.query.filter(
            (ParkingLot.prime_location_name.ilike(f"%{search_query}%")) |
            (ParkingLot.pin_code.ilike(f"%{search_query}%"))
        ).all()
    else:
        parking_lots = ParkingLot.query.all()
        
    for lot in parking_lots:
        occupied = 0
        for spot in lot.parking_spots:
            if spot.status == 'O':
                occupied += 1
        lot.occupied_count = occupied

    recent_reservations = Reservation.query.filter_by(user_id=current_user.id).order_by(Reservation.parking_timestamp.desc()).limit(10).all()

    return render_template('user_dashboard.html', 
                           user=current_user,
                           parking_lots=parking_lots,
                           recent_reservations=recent_reservations,
                           search_query=search_query)
    
# ---------- EDIT PROFILE ----------
@user_bp.route('/edit_profile', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if current_user.is_admin:
        return redirect(url_for('auth.login'))

    user = User.query.get_or_404(current_user.id)

    if request.method == 'POST':
        user.full_name = request.form.get('full_name')
        user.address = request.form.get('address')
        user.pin_code = request.form.get('pin_code')
        password = request.form.get('password')

        # update password
        if password:
            user.password = generate_password_hash(password)

        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('user.user_dashboard'))

    return render_template('edit_profile.html', user=user)

#----------------USER SUMMARY---------------------
@user_bp.route('/user/summary')
@login_required
def user_summary():
    if current_user.is_admin:
        return redirect(url_for('auth.login'))

    # All parking lots
    all_lots = ParkingLot.query.all()
    lot_usage = {lot.prime_location_name: 0 for lot in all_lots}
    lot_costs = {lot.prime_location_name: 0.0 for lot in all_lots}

    # ---------- USAGE ----------
    usage_reservations = (
        db.session.query(Reservation)
        .join(ParkingSpot, Reservation.spot_id == ParkingSpot.id)
        .join(ParkingLot, ParkingSpot.lot_id == ParkingLot.id)
        .filter(Reservation.user_id == current_user.id)
        .all()
    )

    for r in usage_reservations:
        if r.spot and r.spot.parking_lot:
            lot_name = r.spot.parking_lot.prime_location_name
            if lot_name in lot_usage:
                lot_usage[lot_name] += 1

    # ---------- COST ----------
    cost_reservations = (
        db.session.query(Reservation)
        .join(ParkingSpot, Reservation.spot_id == ParkingSpot.id)
        .join(ParkingLot, ParkingSpot.lot_id == ParkingLot.id)
        .filter(
            Reservation.user_id == current_user.id,
            Reservation.parking_timestamp.isnot(None),
            Reservation.leaving_timestamp.isnot(None)
        )
        .all()
    )

    for r in cost_reservations:
        if r.spot and r.spot.parking_lot:
            lot_name = r.spot.parking_lot.prime_location_name
            duration_hours = (r.leaving_timestamp - r.parking_timestamp).total_seconds() / 3600
            lot_costs[lot_name] += round(duration_hours * r.spot.parking_lot.price, 2)

    # ---------- Prepare for Chart.js ----------
    lot_labels = list(lot_usage.keys())
    lot_counts = list(lot_usage.values())
    lot_cost_values = list(lot_costs.values())

    return render_template(
        'user_summary.html',
        lot_labels=lot_labels,
        lot_counts=lot_counts,
        lot_costs=lot_cost_values
    )
