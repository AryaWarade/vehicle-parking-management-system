from flask import Blueprint,render_template, request, redirect, session, url_for,flash
from models.model import db, User, ParkingLot, ParkingSpot, Reservation
from flask_login import login_required,current_user

admin_bp=Blueprint('admin',__name__)

#----------------ADMIN DASHBOARD---------------
@admin_bp.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        return redirect(url_for('auth.login')) 
    users = User.query.all()
    parking_lots = ParkingLot.query.all()
    return render_template('admin_dashboard.html', users=users, parking_lots=parking_lots)

#-------------ADMIN USERS-------------------------
@admin_bp.route('/admin/users')
@login_required
def admin_users():
    if not current_user.is_admin:
        return redirect(url_for('auth.login'))
    users = User.query.all()
    return render_template('admin_users.html', users=users)

#------------CREATE PARKING LOTS---------------
@admin_bp.route('/admin/parking_lot/create', methods=['GET', 'POST'])
@login_required
def create_parking_lot():
    if not current_user.is_admin:
        return redirect(url_for('auth.login'))
    if request.method == 'POST':
        prime_location_name = request.form.get('prime_location_name')
        price = float(request.form.get('price'))
        address = request.form.get('address')
        pin_code = request.form.get('pin_code')
        max_spots = int(request.form.get('maximum_number_of_spots'))

        new_lot = ParkingLot(
            prime_location_name=prime_location_name,
            price=price,
            address=address,
            pin_code=pin_code,
            maximum_number_of_spots=max_spots
        )
        db.session.add(new_lot)
        db.session.commit()
        
        for i in range(max_spots):
            new_spot = ParkingSpot(lot_id=new_lot.id)
            db.session.add(new_spot)
        db.session.commit()

        return redirect(url_for('admin.admin_dashboard'))
    return render_template('create_parking_lot.html')

# ----------EDIT PARKING LOTS-----------
@admin_bp.route('/admin/parking_lot/edit/<int:lot_id>', methods=['GET', 'POST'])
@login_required
def edit_parking_lot(lot_id):
    if not current_user.is_admin:
        return redirect(url_for('auth.login'))

    lot = ParkingLot.query.get_or_404(lot_id)

    if ParkingSpot.query.filter_by(lot_id=lot_id, status='O').count() > 0:
        flash(" Cannot edit while spots are occupied", "warning")
        return redirect(url_for('admin.admin_dashboard'))

    if request.method == 'POST':
        lot.prime_location_name = request.form.get('prime_location_name')
        lot.address = request.form.get('address')
        lot.pin_code = request.form.get('pin_code')
        lot.price = float(request.form.get('price'))
        new_max_spots = int(request.form.get('maximum_number_of_spots'))

        existing_spots = ParkingSpot.query.filter_by(lot_id=lot_id).all()
        existing_count = len(existing_spots)
        if new_max_spots > existing_count:
            for _ in range(new_max_spots - existing_count):
                db.session.add(ParkingSpot(lot_id=lot_id))
        elif new_max_spots < existing_count:
            removable_spots = ParkingSpot.query.filter_by(lot_id=lot_id, status='A')\
                                .order_by(ParkingSpot.id.desc())\
                                .limit(existing_count - new_max_spots).all()
            for spot in removable_spots:
                db.session.delete(spot)

        lot.maximum_number_of_spots = new_max_spots
        db.session.commit()
        flash("Parking lot updated successfully.", "success")
        return redirect(url_for('admin.admin_dashboard'))

    return render_template('edit_parking_lot.html', lot=lot)


#------- VIEW SPOTS------------------
@admin_bp.route('/view_parking_spots/<int:lot_id>', methods=['GET'])
@login_required
def view_parking_spots(lot_id):
    if not current_user.is_admin:
        return redirect(url_for('auth.login'))
    lot = ParkingLot.query.get_or_404(lot_id)
    spots = ParkingSpot.query.filter_by(lot_id=lot_id).all()

    user_map = {}

    for spot in spots:
        if spot.status == 'O':
            reservation = Reservation.query.filter_by(
                spot_id=spot.id,
                leaving_timestamp=None
            ).order_by(Reservation.id.desc()).first()

            if reservation and reservation.user:
                user_map[spot.id] = {
                    "full_name": reservation.user.full_name,
                    "email": reservation.user.email,
                    "vehicle_number": reservation.vehicle_number,
                    "parking_time": reservation.parking_timestamp.strftime("%Y-%m-%d %H:%M:%S")
                }
    return render_template(
        'view_parking_spots.html',
        lot=lot,
        spots=spots,
        user_map=user_map
    )

# ----------ViEW USER DETAILS----------
@admin_bp.route('/admin/view_user_details/<int:spot_id>')
@login_required
def view_user_details(spot_id):
    if not current_user.is_admin:
        return redirect(url_for('auth.login'))

    reservation = Reservation.query.filter_by(
        spot_id=spot_id,
        leaving_timestamp=None
    ).order_by(Reservation.id.desc()).first()

    if not reservation:
        flash("No active reservation for this spot.", "warning")
        return redirect(url_for('admin.admin_dashboard'))

    user = reservation.user
    return render_template('view_user_details.html', user=user, reservation=reservation)


# ---------- DELETE PARKING LOT ----------
@admin_bp.route('/delete_parking_lot/<int:lot_id>', methods=['POST'])
@login_required
def delete_parking_lot(lot_id):
    if not current_user.is_admin:
        return redirect(url_for('auth.login'))
    lot = ParkingLot.query.get_or_404(lot_id)

    occupied_spots = ParkingSpot.query.filter_by(lot_id=lot.id, status='O').first()

    if occupied_spots:
        flash(" Can't delete: lot has occupied parking spots.", "danger")
        return redirect(url_for('admin.admin_dashboard'))
    ParkingSpot.query.filter_by(lot_id=lot.id).delete()
    db.session.delete(lot)
    db.session.commit()

    flash(" Parking lot deleted successfully.", "success")
    return redirect(url_for('admin.admin_dashboard'))

#-----------ADMIN SUMMARY----------------------------------
@admin_bp.route('/admin/summary')
@login_required
def admin_summary():
    lots = ParkingLot.query.all()

    lot_names = []
    revenues = []
    
    #revenue chart
    for lot in lots:
        total_revenue = 0.0

        for spot in lot.parking_spots:
            for res in spot.reservation:
                if res.leaving_timestamp and res.parking_cost:
                    total_revenue += res.parking_cost
            
        lot_names.append(lot.prime_location_name)
        revenues.append(round(total_revenue, 2))
        
    # spot chart
    spot_summary = {
        "Occupied": sum(1 for lot in lots for spot in lot.parking_spots if spot.status == 'O'),
        "Available": sum(1 for lot in lots for spot in lot.parking_spots if spot.status == 'A')
    }

    # lot chart
    lot_status = {
        "Full": sum(1 for lot in lots if all(spot.status == 'O' for spot in lot.parking_spots)),
        "Partially Full": sum(1 for lot in lots if any(spot.status == 'O' for spot in lot.parking_spots) and any(spot.status == 'A' for spot in lot.parking_spots)),
        "Empty": sum(1 for lot in lots if all(spot.status == 'A' for spot in lot.parking_spots))
    }

    return render_template(
        'admin_summary.html',
        lot_names=lot_names,
        revenues=revenues,
        spot_summary=spot_summary,
        lot_status=lot_status
    )
    
    
